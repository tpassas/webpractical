if ($('.cookie-banner').length) {
  $('.cookie-banner').slideDown(800);   
}

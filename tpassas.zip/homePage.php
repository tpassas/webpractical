<!doctype html>
<html>
<head>
<link href="css/homePage.css" rel="stylesheet" type="text/css">
<script src="http://use.edgefonts.net/source-sans-pro:n2:default.js" type="text/javascript"></script>
	<style type="text/css">
		#map {
			width: 400px;
			height: 200px;
		}
    #special{
      text-align:right;
      padding-right: 300px;
      padding-top: 150px;
      
    }
    #image1{
      padding-bottom: 100px;
    }
    #specialp{
      color:black;
      text-decoration: underline;
    }
	</style>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCgpY76bZUzJ-8bZYcvTo274geEJJ5xfbw&callback=initMap"
  	  type="text/javascript"></script>
		<script type="text/javascript">
			x = navigator.geolocation;
			
			x.getCurrentPosition(success, failure);
			
			function success(position)
			{
				var myLat = position.coords.latitude;
				var myLong = position.coords.longitude;
				var coords = new google.maps.LatLng(myLat,myLong);
				
				var mapOptions = {
					zoom:10,
					center: coords,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				}
				var map = new google.maps.Map(document.getElementById("map"), mapOptions);
			 	var marker = new google.maps.Marker({map:map, position:coords});
			}
			function failure() {
			}
		</script>
</head>
<body>
<div class="container"> 
  <header> <a href="">
    <h4 class="logo">Pet Now</h4>
    </a>
    <nav>
      <ul>
        <li><a href="homePage.php">HOME</a></li>
        <li><a href="findPets.php">Find Pets</a></li>
        <li><a href="#singIn">Sing In</a></li>
	    <li><a href="register.php">Register</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="mainBanner" id="mainBanner">
    <h2 class="mainBanner_header">Share your Pet </h2>
    <p class="tagline">Never leave your pet alone</p>  
  </section>
  <!-- About Section -->
  <section class="about" id="about">
    <p class="text_column" data_temp_dwid="1"><strong>Do you want to borrow a pet?</strong>
		<br>A short descpition of the site according to somenone who wants to borrow a pet</p>
    <p class="text_column"><strong>Do you want to borrow your pet to someone?</strong>
		<br>A short description for those who want to borrow their pets </p>
	  
    <p class="text_column"><strong>Do you want to sell your pet?</strong>
		<br>A short description for those who want to sell their pets </p>
  </section>
  <section class="banner">
    <h2 class="security">Leave your pet at safe hands</h2>
    <p class="security_description">When a user registers he is asked to give us his mobile number and after that we send a text to verify his information, so he can not put false information, there are also some rating options where the borrowers are geting rated for each of their services</p>
  </section>
  <footer>
    <article class="footer_column">
      <h3>Reasons to join</h3>
      <img src="images/ReasonsToJoinPic.pg"  class="images"/>
      <p> bulet points me to kathena apo auta ta themata me ligo saltsoula.... Meet new friends, build new Relationships....
		STOP unwanted Pets</p>
    </article>
    <article class="footer_column" >
        <h3>Map</h3>
		<div id="map"  width="400" height="200"></div>
        <p>This is the exact location of the user </p>
    </article>
      
  </footer>
  <section class="footer_banner" id="aboutUs">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="mainBanner_header">What is PetNow</p>
    <div class="button" onclick="window.location.href='aboutUs.html'">About us</div>
  </section>
  <div class="copyright">&copy;2020 - <strong>University Of Sheffield</strong></div>
</div>

<div id="special">
  <img id="image1" src="images/upload_dog.jpg"  class="images"/>
  <p id="specialp">You can upload yours dogs picture here!</p>
  <form action="upload.php" method="post" enctype="multipart/form-data">     
  <input type="file" name="image"/><br><br>
  <input type="submit" value="Upload" name="submit">
</div>

</body>
</html>

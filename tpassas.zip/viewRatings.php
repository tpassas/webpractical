<?php
    include'database.php';
    $query ="SELECT user_id,rateIndex FROM stars ";
    $user_ratings = mysqli_query($conn , $query);
    if($user_ratings->num_rows >0){

        while ($num_rows = $user_ratings->fetch_assoc()) {

            echo "<hr size='1'>";                
            echo '<table border="1">';
            echo '<td>User ID:'.$num_rows['user_id'].'';
            echo '<br>Rating:'.$num_rows['rateIndex'].'';
            echo '</table>';
        }
        
    }
?>
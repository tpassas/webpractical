<?php
if (isset($_GET['accept-cookies'])) {
  setCookie('accept-cookies','true', time() + 3600);
  header('Location: ./');

}
?>

<!DOCTYPE html>  
<HTML>
<head>
  <title>Welcome to our Website</title>
  <link rel="stylesheet" href="website.css" />
</head>
<BODY>w
  <?php
  if (!isset($_COOKIE['accept-cookies'])) {
    ?>
    <div class="cookie-banner">
      <div class="container">
        <p>The website is using cookies. By using this website, we'll assume you consent to <a href="/cookies">the cookies we set</a>.</p>
        <a href="?accept-cookies" class="button">Ok, continue</a>
      </div>
    </div>
    <?php
  }
  ?>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
  <script src="website.js"></script>

  <FORM name = "RegisterForm" ACTION="insertion.php" METHOD="POST">
    <B><U>Register</U></B><BR>


    <BR><B>FirstName:</B><BR>
    <INPUT TYPE ="text" NAME= "FirstName" required pattern ="^[A-Za-z -]+$">



    <BR><B>LastName:</B><BR>
    <INPUT TYPE = "text" NAME = "LastName" required pattern ="^[A-Za-z -]+$">


    <BR><B>MobilePhone:</B><BR>
    <INPUT TYPE ="tel" NAME = "Phone" required pattern = "[0-9]+">

    
    <BR><B>E-mail:</B><BR>
    <INPUT TYPE = "email" NAME = "email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">

    <BR><B>Password:</B><BR>
    <INPUT TYPE = "password" NAME= "Password" required>


    <BR><B>Choose Gender</B><BR>


    <INPUT TYPE= "radio" name = "gender" value = "Male" required>Male<BR>


    <INPUT TYPE= "radio" name = "gender" value = "Female" required>Female<BR>


    <INPUT TYPE = "submit" value = "Sign up">
  </FORM>
</BODY>
</HTML>

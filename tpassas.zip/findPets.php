<?php session_start()?>
<!DOCTYPE html>
<html>
    <head>
        <link href="css/homePage.css" rel="stylesheet" type="text/css">
        <script src="http://use.edgefonts.net/source-sans-pro:n2:default.js" type="text/javascript"></script>
    </head>
    <body>
     
        <div class="container"> 
        <header> <a href="">
        <h4 class="logo">Pet Now</h4>
            </a>
            <nav>
                <ul>
                <?php 
       if (isset($_SESSION['loggedin'])){
        $profile_link = 'profiles.php';
        $logout_link = 'logout.php';
        echo '<li><a href="homePage.php">HOME</a></li>';
        echo'<li><a href="findPets.php">Find Pets</a></li>';
        echo '<li><a href="'.$profile_link.'">Profile</a></li>';
        echo '<li><a href="'.$logout_link.'">Logout</a></li>';
        }else{
          echo'<li><a href="homePage.php">HOME</a></li>';
          echo'<li><a href="findPets.php">Find Pets</a></li>';
          echo' <li><a href="login.php">Sing In</a></li>';
          echo'<li><a href="register.php">Register</a></li>';
     } 
     ?>
                </ul>
            </nav>
        </header>
        <?php 
        include 'viewRatings.php';
        include 'database.php'; 
        $query = "SELECT first_name,last_name,email from users";
        $user_profiles = mysqli_query($conn , $query);

        if($user_profiles->num_rows >0){

            while ($num_rows = $user_profiles->fetch_assoc()) {

                echo "<hr size='1'>";                
                echo '<table border="1">';
                echo '<td>First Name:'.$num_rows['first_name'].'';
                echo '<br>Last Name:'.$num_rows['last_name'].'';
                echo '<br>Email:'.$num_rows['email'].''; 
                echo '</table>';
                include 'stars.php';
                
            }
            
        }
        ?>
        </div>

        <section class="mainBanner_header" >
            Find Your Pet
        </section>
        <section class="banner">
            <h2 class="security">Some text</h2>
            <p class="security_description">Texting.....</p>
        </section>

        
         
         
      
    </body>
    <div class="copyright">&copy;2020 - <strong>University Of Sheffield</strong></div>

 
</html>
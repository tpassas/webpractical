<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "dogs_care";
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$db);
//$conn = new PDO('mysql:host=localhost;dbname=dogs_care','root','');  
if(!$conn){
    die('Could not Connect My Sql:' .mysql_error());
}else
echo "";


/*function CloseCon($conn)
{
    $conn -> close();
}*/

?>
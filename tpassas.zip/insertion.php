<?php
include 'database.php';
$email_error = "Email already in use";
if (!isset($_POST['submit'])) {
    $fname    = $_POST['FirstName'];
    $lname    = $_POST['LastName'];
    $phone    = $_POST['Phone'];
    $email    = $_POST['email'];
    $password = $_POST['Password'];
    $gender   = $_POST['gender'];
    
    
    $checkemail = mysqli_prepare($conn, "SELECT email from users where email = ?");
    $checkemail->bind_param("s", $email);
    $checkemail->execute();
    $results = $checkemail->get_result();

    $dbHost     = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName     = 'dogs_care';

    //Create connection and select DB
    $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

    // Check connection
    if($db->connect_error){
        die("Connection failed: " . $db->connect_error);
}
    

    if (mysqli_num_rows($results) == 1) {
        echo '<div style ="color:blue;"><b>'.$email.'</b> is already in use</div>';
       //header("Location: register.php");

        
    } else {
        //prepare sql query for SQL injection purposes 
        $insert_data = $conn->prepare("INSERT INTO users (first_name  , last_name ,  phone  , email ,  password  ,  gender)VALUES(?, ?, ? ,?, ? ,?)");
        $insert_data->bind_param("ssssss", $fname, $lname, $phone, $email, $password, $gender);
        $insert_data->execute();

        if ($insert_data) {
            echo " Successful insertion";
            header("Location: homepage.php");
        } else {
            echo "Error " . $query . ":" . mysql_error($conn);
            mysql_close($conn);
        }
    }
    
}
?>  